#ifndef __DEBUG_H
#define __DEBUG_H

const char *eventName(int type);

#endif
