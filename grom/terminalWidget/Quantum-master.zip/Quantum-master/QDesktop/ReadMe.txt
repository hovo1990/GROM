QDesktop is a application that gives you a Desktop Wallpaper, Icons, Right Click-Menus, Its simular
to xfce4's Desktop Application but written in Qt4


Create $HOME ./config/chipara/desktop.conf

export QDESKTOP_CONFIG=$HOME/.config/chipara/desktop.conf

And Add

[window]
wallpaper=/home/steven/Picture/default.jpg
iconTheme=oxygen
iconSize=2
showIcons=1
layoutDirection=1
desktopSettings=/home/steven/Desktop/Quantum/QDesktopSettings/QDesktopSettings