About The Quantum Project
-------------------------

The Quantum Project's aim is to create a complete uniformed Hybrid C++/JavaScript 
Hardware, Software & Operating System Development Framework, a modular all in one 
solution to building "System, Desktop, Web, Multimedia, and Game Applications. Doing 
all of this and still keeping 4 key concepts in mind, "Design, Style, Construct, Deploy" 
and 5 rules of engagement.

   1.  Easy To Use
   2.  Documentation
   3.  Support
   4.  Features
   5.  and KISS "Keep It Simple Sam!" :) 


![alt text](http://i51.tinypic.com/33272xd.png) 


Copyright (C) 2011 by Steven Starr

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.




