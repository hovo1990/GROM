?package(eggwm):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="eggwm" command="/usr/bin/eggwm"
