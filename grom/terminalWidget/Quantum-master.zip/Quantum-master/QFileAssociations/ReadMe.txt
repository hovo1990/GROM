QFileAssociations

QFileAssociations is a Mimetype, File Associations editor.

